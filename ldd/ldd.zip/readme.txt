
                  ________               ______            ______
                  \     |                \   |             \   |
                  |  \  | -  --        - | \ |             | \ |
                  (  \  | -\-_- -. _  -  ( \ | -  -- --  - ( \ |
                - |  \  ) .- .\wbcbz7!--/| \ ) -   -   -  /| \ )
              . - |  \  |   -_-------------  |---------------  |
           .    - |  \  |   -//  _________   | //  _________   |
       .. -   .   |  \  |   -\  -        \   ) \  -        \   ) .-
       - -   - - \'  \   \ -  \  ---------  /|  \  ---------  /|
   --------------------------------------------------------------------------
                    ldd - final version - tsconf + vdac demo

  yet another demo from b-state in 0x7e0 - we are alive! (at least me :)

  contribution to zx enhanced compo 2o16 held in...somewhere in ukraine :))

  it was done in less than four days because I was nearly pissed off by some
  people but netherless I did it (thought it was smashed together in last two
  hours before the deadline and suddenly it worked ;)
 
    >>z80 + 4mb ram + tsconf + vdac + ay\ym + eyes + ears + drink required<<
 
  5000w loudspeakers + good monitor recommended

  special greets goes to hacker vbi and ts-labs for great party - keep rockin'!
  also "hi!" to breeze\fishbone, g0blinish and others who supported me.

  FUCKINGS goes to AAA and fucking govnoforum (aka zx-pk.ru) users who really
  think that this demo is a pure animation and "colorcycling". FUCK YOU!

  SUPER-DUPER-MEGA FUCKINGS TO LVD for fake release - DIE, FUCKING MORON!

  see ya @ CSP and CC'2o16!

  wbc.b-state.omsk.russia.17.o2.2o16............wbc.bz7@gmail.com.....blah.blah